import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Mic, 
  Terminal, 
  TrendingUp, 
  Users, 
  Globe, 
  Cpu, 
  BookOpen, 
  ArrowRight, 
  Play, 
  Layers, 
  ChevronLeft,
  ChevronRight,
  Menu,
  X,
  Instagram,
  Twitter,
  Linkedin,
  Youtube,
  Sun,
  Moon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Toaster, toast } from 'sonner';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

// --- Constants ---
const ALIVE_YOUTUBE_URL = "https://www.youtube.com/@alive_podcast_Abrham";
const BRAND_AQUA = "#00D7FF";
const VISIONARY_IMAGE = "https://storage.googleapis.com/dala-prod-public-storage/attachments/6af2f82c-4073-450c-b678-c6d68dff7e08/1777641025526_Layer_3.png";

// --- Components ---

interface NavbarProps {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

const Navbar = ({ theme, toggleTheme }: NavbarProps) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Podcast', href: '#podcast' },
    { name: 'Academy', href: '#academy' },
    { name: 'Agency', href: '#agency' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled 
        ? 'bg-background/80 backdrop-blur-md border-b border-border py-4' 
        : 'bg-transparent py-6'
    }`}>
      <div className="container mx-auto px-6 flex justify-between items-center">
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="text-2xl font-black tracking-tighter"
        >
          ABRAHAM <span className="text-cyan-400">FANTU</span>
        </motion.div>

        {/* Desktop Nav */}
        <div className="hidden md:flex gap-8 items-center">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="text-xs uppercase tracking-widest font-bold text-muted-foreground hover:text-foreground transition-colors"
            >
              {link.name}
            </a>
          ))}
          
          <button 
            onClick={toggleTheme}
            className="p-2 rounded-full hover:bg-muted transition-colors text-foreground"
            aria-label="Toggle Theme"
          >
            {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
          </button>

          <Button 
            variant="outline" 
            className="border-cyan-400 text-foreground hover:bg-cyan-400 hover:text-white transition-all rounded-full px-6" 
            onClick={() => toast.success("Booking a consultation...")}
          >
            Connect
          </Button>
        </div>

        {/* Mobile Toggle */}
        <div className="flex items-center gap-4 md:hidden">
          <button 
            onClick={toggleTheme}
            className="p-2 rounded-full hover:bg-muted transition-colors text-foreground"
          >
            {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <button className="text-foreground" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-background border-b border-border overflow-hidden"
          >
            <div className="flex flex-col p-6 gap-4">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href} 
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-lg font-medium text-muted-foreground"
                >
                  {link.name}
                </a>
              ))}
              <Button className="bg-cyan-400 text-white w-full" onClick={() => { setIsMobileMenuOpen(false); toast.success("Redirecting to Portal..."); }}>Get Started</Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  const titles = ["Entrepreneur", "Investor", "Podcaster", "CEO"];
  const heroImage = "https://storage.googleapis.com/dala-prod-public-storage/attachments/6af2f82c-4073-450c-b678-c6d68dff7e08/1777638257037_dss.jpg";
  
  return (
    <section id="home" className="min-h-screen relative flex items-center pt-20 overflow-hidden bg-background">
      {/* Background Cinematic Lighting */}
      <div className="absolute top-0 right-0 w-2/3 h-full bg-gradient-to-l from-cyan-400/10 to-transparent pointer-events-none z-[1]" />
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-400/5 blur-[150px] rounded-full z-[1] pointer-events-none" />

      {/* Full-Bleed Cinematic Background Image */}
      <div className="absolute inset-0 z-0">
        <motion.div
          initial={{ opacity: 0, scale: 1.1 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.8, ease: "easeOut" }}
          className="w-full h-full relative"
        >
          <img 
            src={heroImage} 
            alt="Abraham Fantu Profile"
            className="w-full h-full object-cover object-center md:object-top transition-all duration-[3000ms]"
            style={{ filter: 'contrast(1.1) brightness(0.9)' }}
          />
          {/* Enhanced Overlays for Readability and Depth */}
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/60 md:via-background/30 to-transparent z-10" />
          <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-background to-transparent z-10" />
          <div className="absolute inset-x-0 top-0 h-48 bg-gradient-to-b from-background to-transparent z-10" />
        </motion.div>
      </div>

      <div className="container mx-auto px-6 relative z-20 flex flex-col md:flex-row items-center min-h-[calc(100vh-80px)]">
        <div className="w-full md:w-3/5">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <Badge className="bg-cyan-400/20 text-cyan-400 border-cyan-400/30 mb-8 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-[0.2em]">
              Visionary • Scale • Impact
            </Badge>
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: -200 }}
            animate={{ 
              y: [-200, 0, -40, 0, -15, 0],
              opacity: [0, 1, 1, 1, 1, 1]
            }}
            transition={{ 
              duration: 2, 
              times: [0, 0.4, 0.6, 0.8, 0.9, 1],
              ease: "easeOut" 
            }}
            className="text-3xl md:text-[5.5rem] font-black tracking-tighter leading-[0.9] mb-10 uppercase text-foreground"
          >
            AUTHORITY <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-cyan-300 to-cyan-500 animate-pulse">
              FIRST.
            </span>
          </motion.h1>
          
          <motion.div 
            initial={{ opacity: 0, y: -100 }}
            animate={{ 
              y: [-100, 0, -20, 0],
              opacity: [0, 1, 1, 1]
            }}
            transition={{ 
              duration: 1.5, 
              delay: 0.4,
              times: [0, 0.6, 0.8, 1],
              ease: "easeOut" 
            }}
            className="h-16 overflow-hidden mb-10 relative flex items-center border-l-4 border-cyan-400 pl-8"
          >
            <motion.div
              animate={{
                y: [-192, -128, -64, 0],
              }}
              transition={{
                duration: 5,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="flex flex-col"
            >
              {["CEO", "Entrepreneur", "Investor", "Podcaster", "CEO"].map((title, i) => (
                <div key={i} className="h-16 flex items-center text-3xl md:text-4xl font-light text-muted-foreground tracking-[0.25em] uppercase">
                  {title}
                </div>
              ))}</motion.div>
          </motion.div>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="text-muted-foreground text-lg md:text-xl max-w-xl mb-12 leading-relaxed font-medium"
          >
            Building the next generation of <span className="text-foreground">African Unicorns</span> through high-velocity systems, 
            strategic media distribution, and cognitive mindset engineering.
          </motion.p>

          <div className="flex flex-wrap gap-6">
            <motion.a
              href={ALIVE_YOUTUBE_URL}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 1 }}
              whileHover={{ scale: 1.05, boxShadow: `0 0 30px rgba(34,211,238,0.3)`, backgroundColor: BRAND_AQUA, color: "#fff" }}
              whileTap={{ scale: 0.95 }}
              className="bg-foreground text-background px-10 py-5 rounded-full font-black text-lg flex items-center gap-3 transition-all group cursor-pointer"
            >
              <div className="w-8 h-8 rounded-full bg-background/10 flex items-center justify-center group-hover:bg-background/20 transition-colors">
                <Play size={16} className="fill-current translate-x-0.5" />
              </div>
              Watch Podcast
            </motion.a>
          </div>
        </div>
      </div>

      {/* Dynamic Background Ticker - Preserve existing functionality */}
      <div className="absolute bottom-0 left-0 w-full py-8 border-y border-border bg-background/40 backdrop-blur-sm overflow-hidden hidden md:block z-20">
        <motion.div
          animate={{ x: [0, -1000] }}
          transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
          className="flex whitespace-nowrap gap-24 items-center opacity-40"
        >
          {Array(8).fill(null).map((_, i) => (
            <div key={i} className="flex items-center gap-24">
              <span className="text-5xl font-black uppercase tracking-tighter" style={{ WebkitTextStroke: '1px var(--foreground)', color: 'transparent', opacity: 0.1 }}>
                High Velocity Execution
              </span>
              <div className="w-2 h-2 rounded-full bg-cyan-400" />
              <span className="text-5xl font-black uppercase tracking-tighter text-foreground/10">
                African Unicorn Matrix
              </span>
              <div className="w-2 h-2 rounded-full bg-foreground/20" />
              <span className="text-5xl font-black uppercase tracking-tighter" style={{ WebkitTextStroke: '1px #22d3ee', color: 'transparent', opacity: 0.2 }}>
                Media Distribution
              </span>
              <div className="w-2 h-2 rounded-full bg-cyan-400" />
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

const Timeline = () => {
  const milestones = [
    { year: "1997", title: "The Visionary Born", desc: "Born in Addis Ababa, Ethiopia into a middle-class family. The foundation of a global perspective and entrepreneurial spirit." },
    { year: "2010 - 2016", title: "Early Business & Gig Work", desc: "Started my journey in the business world through freelancing and various gig works, learning the fundamentals of value exchange." },
    { year: "2016 - 2018", title: "The Studio Era", desc: "Founded my first major photography and wedding studio, mastering the art of visual storytelling and client management at scale." },
    { year: "2018 - 2024", title: "Marketing & Strategy", desc: "Deep-dived into the world of marketing, building high-authority brands and implementing strategic media distribution systems." },
    { year: "2023", title: "Alive Academy Launch", desc: "Started coaching through Alive Academy, empowering others with the systems and mindset needed to scale their digital presence." },
    { year: "2024 - Alive", title: "The Ecosystem", desc: "Launched ALIVE Podcast and founded 3 distinct companies. Continuing to build self-development areas and coaching others to financial freedom." },
  ];

  return (
    <section id="timeline" className="py-32 bg-background border-t border-border overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center mb-24 relative">
          <div className="text-left relative z-10">
            <Badge className="bg-muted text-muted-foreground border-border mb-6 uppercase tracking-[0.2em]">The Journey</Badge>
            <h2 className="text-5xl md:text-7xl font-black mb-6 tracking-tighter text-foreground">
              The 28-Year-Old <br />
              <span className="text-cyan-400">Visionary</span>
            </h2>
            <p className="text-muted-foreground text-xl max-w-xl leading-relaxed">
              A decade of building, scaling, and architecting high-impact businesses and personal development systems. 
              The journey from a digital nomad to a media powerhouse builder.
            </p>
          </div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, x: 100 }}
            whileInView={{ opacity: 1, scale: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2, ease: "easeOut" }}
            className="relative flex justify-center md:justify-end"
          >
            {/* Background Glow */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-cyan-400/10 blur-[100px] rounded-full pointer-events-none" />
            
            <div className="relative group max-w-md md:max-w-full">
              {/* Image with background removal effect */}
              <div className="relative overflow-hidden rounded-[4rem] transition-all duration-700">
                <img 
                  src={VISIONARY_IMAGE} 
                  alt="The Visionary"
                  className="w-full h-auto object-contain transition-all duration-700 group-hover:scale-105"
                  style={{ 
                    filter: 'drop-shadow(0 0 20px rgba(0, 215, 255, 0.2))',
                    maskImage: 'linear-gradient(to bottom, black 85%, transparent 100%)',
                    WebkitMaskImage: 'linear-gradient(to bottom, black 85%, transparent 100%)'
                  }}
                />
              </div>
              
              {/* Floating Decorative Elements */}
              <motion.div 
                animate={{ y: [0, -15, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -top-10 -right-10 w-24 h-24 bg-cyan-400/20 backdrop-blur-xl rounded-full border border-cyan-400/30 flex items-center justify-center"
              >
                <Cpu className="text-cyan-400" size={32} />
              </motion.div>
            </div>
          </motion.div>
        </div>

        <div className="relative max-w-5xl mx-auto">
          {/* Vertical Line */}
          <div className="absolute left-1/2 transform -translate-x-1/2 w-px h-full bg-gradient-to-b from-transparent via-cyan-400/40 to-transparent hidden md:block" />

          <div className="space-y-32">
            {milestones.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.8 }}
                className={`relative flex flex-col md:flex-row items-center ${index % 2 === 0 ? 'md:justify-start' : 'md:justify-end md:flex-row-reverse'}`}
              >
                {/* Content */}
                <div className={`w-full md:w-[45%] ${index % 2 === 0 ? 'md:text-right' : 'md:text-left'}`}>
                  <div className="bg-card p-10 rounded-[2.5rem] border border-border hover:border-cyan-400/30 transition-all group relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-400/5 blur-3xl rounded-full -translate-y-1/2 translate-x-1/2" />
                    
                    {/* Small Face Avatar for "Stape by Stape" */}
                    <div className={`flex items-center gap-4 mb-4 ${index % 2 === 0 ? 'justify-end' : 'justify-start'}`}>
                      <div className="w-10 h-10 rounded-full overflow-hidden border border-cyan-400/30 shadow-lg">
                        <img src={VISIONARY_IMAGE} alt="Face" className="w-full h-full object-cover" />
                      </div>
                      <span className="text-4xl md:text-5xl font-black text-cyan-400/10 group-hover:text-cyan-400/20 transition-colors">
                        {item.year}
                      </span>
                    </div>

                    <h3 className="text-3xl font-bold mb-4 text-foreground">{item.title}</h3>
                    <p className="text-muted-foreground text-lg leading-relaxed">{item.desc}</p>
                  </div>
                </div>

                {/* Dot */}
                <div className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 rounded-full bg-cyan-400 shadow-[0_0_20px_#22d3ee] hidden md:block z-10" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const PodcastHub = () => {
  const episodes = [
    {
      title: "በሀንዝ ሀገር ብዙ ችግር አይቻለሁ | Zeweter Desalegn",
      url: "https://www.youtube.com/watch?v=NvZSNEDHovM",
      id: "NvZSNEDHovM",
      category: "Experience"
    },
    {
      title: "በእሳት የተፈተነች ጀግና እናት | ALIVE PODCAST",
      url: "https://www.youtube.com/watch?v=NvZSNEDHovM",
      id: "NvZSNEDHovM",
      category: "Story"
    },
    {
      title: "ሰው ሳይሆን ጊዜ እንዳይለያያችሁ ፍሩ! | ብሊንግ | Bling",
      url: "https://www.youtube.com/watch?v=Sw0uL9-A-L4",
      id: "Sw0uL9-A-L4",
      category: "Relationships"
    },
    {
      title: "4ቱ የውጤታማ ሰዎች መገለጫ! | ዳንኤል አያሌው | Daniel Ayalew",
      url: "https://www.youtube.com/watch?v=A-I4TwsaWWw",
      id: "A-I4TwsaWWw",
      category: "Productivity"
    },
    {
      title: "ከ 6 አመት አለማትረፍ እስከ 5 ድርጅት ባለቤትነት | ሳራ መሀመድ | Sara Mohammed",
      url: "https://www.youtube.com/watch?v=TIovNBOrtKk",
      id: "TIovNBOrtKk",
      category: "Business"
    },
    {
      title: "ክፍል_2፤ Gaslighters ጋር ማድረግ ያለብን ጥንቃቄ! | ጌታ ዋለልኝ | Geta Walelign",
      url: "https://www.youtube.com/watch?v=UT300nkXngI",
      id: "UT300nkXngI",
      category: "Mindset"
    },
    {
      title: "በኑሮ ላይ ሀይል የማግኘት ጥበብ! ክፍል፤3 | ጌታ ዋለልኝ | Geta Walelign",
      url: "https://www.youtube.com/watch?v=8z_zlbUohCE",
      id: "8z_zlbUohCE",
      category: "Wisdom"
    },
    {
      title: "በአርሞሞ ራሴን አገኘሁ! | አዶናይ | Adonay",
      url: "https://www.youtube.com/watch?v=OQB2RpLCAkU",
      id: "OQB2RpLCAkU",
      category: "Self-Discovery"
    },
    {
      title: "ምን ባደርግ ነው ሰዎች የሚወዱኝ? | ኤርሚያስ ኪሮስ | Ermiyas Kiros",
      url: "https://www.youtube.com/watch?v=NgQU32TvvhI",
      id: "NgQU32TvvhI",
      category: "Social"
    },
    {
      title: "ለጤናችን እጅግ አስፈላጊ የሆነውን እንቅልፍ የምናጣው ለምንድነው? | ቃልኪዳን ይርጋ",
      url: "https://www.youtube.com/watch?v=EQAL777CNcY",
      id: "EQAL777CNcY",
      category: "Health"
    },
    {
      title: "ይህን በቀን አንድ ጊዜ ካደረጋችሁ ዶፓሚናችሁ ይስተካከላል! | Addiction Recovery",
      url: "https://www.youtube.com/watch?v=sMdwM6OI42U",
      id: "sMdwM6OI42U",
      category: "Habits"
    },
    {
      title: "በ1500 ብር የተጀመረ የሚሊየነርነት ጉዞ! በላይ ሞርዴ | Belay Morde",
      url: "https://www.youtube.com/watch?v=TZMr-w7YNio",
      id: "TZMr-w7YNio",
      category: "Entrepreneurship"
    }
  ];

  return (
    <section id="podcast" className="py-32 overflow-hidden bg-background">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
          <div className="w-full">
            <Badge className="bg-red-500/10 text-red-500 border-red-500/20 mb-6 px-4 py-1.5 rounded-full uppercase tracking-[0.2em] text-[10px] font-black">
              • Featured Episodes
            </Badge>
            <h2 className="text-6xl md:text-7xl font-black tracking-tighter text-foreground uppercase italic">ALIVE <span className="text-cyan-400">PODCAST</span></h2>
            <p className="text-muted-foreground mt-6 text-xl max-w-2xl leading-relaxed">
              Blueprint for high-net-worth execution. One conversation, 40+ assets, global dominance.
            </p>
          </div>
          <div className="flex gap-4">
            <a href={ALIVE_YOUTUBE_URL} target="_blank" rel="noopener noreferrer">
              <Button variant="ghost" className="text-cyan-400 text-lg gap-2 hover:bg-cyan-400/10 py-8 px-8 rounded-2xl transition-all whitespace-nowrap">
                Explore All <ChevronRight size={20} />
              </Button>
            </a>
          </div>
        </div>

        {/* Carousel Container */}
        <div className="relative mb-24 px-4">
          <Carousel
            opts={{
              align: "start",
              loop: true,
            }}
            className="w-full"
          >
            <CarouselContent className="-ml-4">
              {episodes.map((ep, i) => (
                <CarouselItem key={i} className="pl-4 basis-full sm:basis-1/2 lg:basis-1/3 xl:basis-1/4">
                  <motion.a
                    href={ep.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.05 }}
                    whileHover={{ y: -15, scale: 1.02 }}
                    className="relative aspect-[16/9] group cursor-pointer overflow-hidden rounded-[2rem] border border-border block shadow-2xl"
                  >
                    <img 
                      src={`https://img.youtube.com/vi/${ep.id}/hqdefault.jpg`} 
                      alt={ep.title}
                      className="w-full h-full object-cover grayscale-[0.3] group-hover:grayscale-0 transition-all duration-700"
                    />
                    
                    {/* Hover Overlay with Metadata Reveal */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/60 to-transparent p-6 flex flex-col justify-end opacity-0 group-hover:opacity-100 transition-all duration-500 backdrop-blur-[2px]">
                      <div className="transform transition-transform duration-500 group-hover:translate-y-0 translate-y-4">
                        <span className="text-[10px] uppercase font-black text-cyan-400 mb-2 tracking-[0.2em] block">
                          {ep.category}
                        </span>
                        <h4 className="text-xl font-black mb-1 leading-tight text-white group-hover:text-cyan-400 transition-colors">
                          {ep.title}
                        </h4>
                        <div className="mt-4 flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center">
                            <Play size={14} className="fill-black text-black ml-0.5" />
                          </div>
                          <span className="text-[10px] font-black uppercase tracking-widest text-white">Watch Episode</span>
                        </div>
                      </div>
                    </div>
                  </motion.a>
                </CarouselItem>
              ))}
            </CarouselContent>
            
            {/* Custom Styled Navigation Buttons */}
            <div className="hidden md:block">
              <CarouselPrevious className="left-[-2rem] bg-background/80 border-border text-foreground hover:bg-cyan-400 border-none transition-all" />
              <CarouselNext className="right-[-2rem] bg-background/80 border-border text-foreground hover:bg-cyan-400 border-none transition-all" />
            </div>
          </Carousel>
        </div>

        {/* New Requested Text Element */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12 border-l-4 border-cyan-400 pl-8"
        >
          <h4 className="text-2xl md:text-3xl font-black text-foreground uppercase tracking-widest leading-tight">
            2024 - OS Digital Entrepreneurship <br />
            <span className="text-cyan-400">& Global Influence Journey</span>
          </h4>
        </motion.div>

        {/* Distribution Matrix (The Media Engine/House) */}
        <div className="bg-card border border-border rounded-[3rem] p-10 md:p-20 relative overflow-hidden shadow-2xl">
          <div className="absolute top-0 right-0 w-1/2 h-full bg-cyan-400/5 blur-[120px] pointer-events-none" />
          <div className="grid lg:grid-cols-2 gap-16 items-center relative z-10">
            <div>
              <Badge className="bg-cyan-400/20 text-cyan-400 border-cyan-400/30 mb-8 px-4 py-1 rounded-full uppercase tracking-widest text-[10px] font-black">
                The Media Engine
              </Badge>
              <h3 className="text-5xl font-black mb-8 tracking-tighter text-foreground">The Distribution Matrix</h3>
              <p className="text-muted-foreground text-xl leading-relaxed mb-12">
                We don't just record podcasts. We activate a **Global Presence Engine**. 
                1 hour of raw execution transforms into 40+ high-velocity assets across every major platform.
              </p>
              <div className="grid grid-cols-2 gap-10">
                <div className="flex gap-4">
                  <div className="w-14 h-14 bg-muted rounded-2xl flex items-center justify-center text-cyan-400 border border-border">
                    <Layers size={24} />
                  </div>
                  <div>
                    <h5 className="font-black text-3xl text-foreground">40+</h5>
                    <p className="text-xs uppercase tracking-widest text-muted-foreground font-bold mt-1">Viral Assets</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="w-14 h-14 bg-muted rounded-2xl flex items-center justify-center text-cyan-400 border border-border">
                    <Globe size={24} />
                  </div>
                  <div>
                    <h5 className="font-black text-3xl text-foreground">10+</h5>
                    <p className="text-xs uppercase tracking-widest text-muted-foreground font-bold mt-1">Platforms</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-cyan-400 to-cyan-500 rounded-[2.5rem] blur opacity-20 group-hover:opacity-40 transition duration-1000"></div>
              <img 
                src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/8a369393-0e89-4a52-b082-5dd06ec0ffde/taza-branding-b090bee6-1775566416732.webp" 
                alt="Distribution Matrix"
                className="relative rounded-[2rem] border border-border w-full"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const AliveAcademy = () => {
  return (
    <section id="academy" className="py-32 relative bg-background">
      <div className="container mx-auto px-6">
        <div className="bg-card border border-cyan-400/20 rounded-[4rem] p-10 md:p-24 relative overflow-hidden shadow-2xl">
          <div className="absolute top-0 right-0 w-full h-full opacity-10 pointer-events-none grayscale">
            <img 
              src="https://storage.googleapis.com/dala-prod-public-storage/generated-images/8a369393-0e89-4a52-b082-5dd06ec0ffde/academy-banner-9d4ccb4c-1775566417271.webp" 
              alt="Academy"
              className="w-full h-full object-cover"
            />
          </div>
          
          <div className="relative z-10 max-w-3xl">
            <Badge className="bg-cyan-400/20 text-cyan-400 border-cyan-400/30 mb-8 px-4 py-1.5 rounded-full uppercase tracking-widest text-[10px] font-black">
              Elite Education
            </Badge>
            <h2 className="text-6xl md:text-8xl font-black mb-10 tracking-tighter text-foreground uppercase">ALIVE <br /><span className="text-cyan-400">ACADEMY</span></h2>
            <p className="text-2xl text-muted-foreground mb-12 leading-relaxed font-medium">
              Don't just watch. Execute. Our portal focuses on <span className="text-foreground">Value-Based Scaling</span> and <span className="text-foreground">AI Content Automation</span> for the digital-first elite.
            </p>
            
            <div className="flex flex-col md:flex-row gap-12 mb-16">
              <div className="flex items-center gap-5">
                <div className="w-16 h-16 bg-cyan-400 rounded-2xl flex items-center justify-center shadow-lg">
                  <BookOpen size={28} className="text-white" />
                </div>
                <div>
                  <h4 className="font-black text-xl text-foreground">Scale Matrix Course</h4>
                  <p className="text-sm text-muted-foreground font-medium">The architecture for 10x growth.</p>
                </div>
              </div>
              <div className="flex items-center gap-5">
                <div className="w-16 h-16 bg-muted border border-border rounded-2xl flex items-center justify-center">
                  <Cpu size={28} className="text-foreground/60" />
                </div>
                <div>
                  <h4 className="font-black text-xl text-foreground">AI Content Engines</h4>
                  <p className="text-sm text-muted-foreground font-medium">Automating your authority at scale.</p>
                </div>
              </div>
            </div>

            <Button className="bg-cyan-400 hover:bg-cyan-600 text-white px-12 py-8 rounded-[2rem] text-xl font-black transition-all shadow-xl" onClick={() => toast.success("Opening Enrollment...")}>
              Join the Cohort
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

const TazaMarketing = () => {
  return (
    <section id="agency" className="py-32 bg-foreground text-background rounded-t-[5rem]">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row gap-20 items-center">
          <div className="w-full md:w-1/2">
            <Badge className="bg-cyan-400/10 text-cyan-400 border-cyan-400/20 mb-8 px-4 py-1 rounded-full uppercase tracking-widest text-[10px] font-black">
              Media House
            </Badge>
            <h2 className="text-7xl md:text-8xl font-black tracking-tighter mb-10 leading-[0.85] text-background uppercase">
              HIGH-VELOCITY <br />EXECUTION.
            </h2>
            <p className="text-background/60 text-2xl mb-16 leading-relaxed">
              Taza Marketing is a B2B media powerhouse. We build the <span className="text-background font-bold">40-Account Distribution Matrix</span> for elite brands that need to dominate the noise.
            </p>
            
            <div className="space-y-12">
              <div className="border-l-4 border-cyan-400 pl-8">
                <h4 className="text-3xl font-black mb-4 uppercase tracking-tight">Omni-Presence</h4>
                <p className="text-background/50 text-lg">We don't do social media management. We do total digital dominance.</p>
              </div>
              <div className="border-l-4 border-background pl-8">
                <h4 className="text-3xl font-black mb-4 uppercase tracking-tight">Systems-First</h4>
                <p className="text-background/50 text-lg">Architected for maximum impact and ROI in the modern digital landscape.</p>
              </div>
            </div>

            <Button className="mt-16 bg-background text-foreground hover:bg-muted px-12 py-8 rounded-full font-black text-xl transition-all shadow-xl" onClick={() => toast.success("Agency contact initiated...")}>
              Scale Your Brand
            </Button>
          </div>
          
          <div className="w-full md:w-1/2 relative">
            <div className="grid grid-cols-2 gap-8">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className={`aspect-square bg-background/10 rounded-[3rem] overflow-hidden shadow-inner ${i % 2 === 0 ? 'mt-12' : ''}`}>
                  <div className="w-full h-full bg-gradient-to-br from-background/5 to-background/20 opacity-50" />
                </div>
              ))}
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <motion.div 
                whileHover={{ scale: 1.05 }}
                className="bg-background p-12 rounded-[3.5rem] shadow-2xl border border-background/10 max-w-sm text-center"
              >
                <h3 className="text-6xl font-black text-cyan-400 mb-4 tracking-tighter">40+</h3>
                <p className="font-black text-2xl mb-4 text-foreground uppercase tracking-tight">Asset Distribution</p>
                <p className="text-sm text-muted-foreground font-medium uppercase tracking-[0.2em]">B2B Branding Blueprint</p>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="bg-background text-foreground py-32 border-t border-border">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-start mb-24 gap-16">
          <div>
            <div className="text-4xl font-black tracking-tighter mb-8">
              ABRAHAM <span className="text-cyan-400">FANTU</span>
            </div>
            <p className="text-muted-foreground max-w-sm text-lg leading-relaxed font-medium">
              Entrepreneur, Investor, and Architect of high-velocity business systems and strategic media networks.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-16 md:gap-24">
            <div>
              <h5 className="font-black mb-8 text-xs uppercase tracking-[0.3em] text-cyan-400">Ecosystem</h5>
              <ul className="space-y-5 text-muted-foreground text-sm font-bold">
                <li><a href="#academy" className="hover:text-cyan-400 transition-colors">Alive Academy</a></li>
                <li><a href="#agency" className="hover:text-cyan-400 transition-colors">Taza Marketing</a></li>
                <li><a href="#podcast" className="hover:text-cyan-400 transition-colors">ALIVE Podcast</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-black mb-8 text-xs uppercase tracking-[0.3em] text-cyan-400">Resources</h5>
              <ul className="space-y-5 text-muted-foreground text-sm font-bold">
                <li><a href="#" className="hover:text-cyan-400 transition-colors">Speaking</a></li>
                <li><a href="#" className="hover:text-cyan-400 transition-colors">Consulting</a></li>
                <li><a href="#" className="hover:text-cyan-400 transition-colors">Press Kit</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-black mb-8 text-xs uppercase tracking-[0.3em] text-cyan-400">Connect</h5>
              <div className="flex gap-6">
                <Instagram className="text-muted-foreground hover:text-cyan-400 transition-all cursor-pointer" size={24} />
                <Twitter className="text-muted-foreground hover:text-cyan-400 transition-all cursor-pointer" size={24} />
                <Linkedin className="text-muted-foreground hover:text-cyan-400 transition-all cursor-pointer" size={24} />
                <a href={ALIVE_YOUTUBE_URL} target="_blank" rel="noopener noreferrer">
                  <Youtube className="text-muted-foreground hover:text-cyan-400 transition-all cursor-pointer" size={24} />
                </a>
              </div>
            </div>
          </div>
        </div>
        
        <div className="pt-12 border-t border-border flex flex-col md:flex-row justify-between items-center gap-6 text-[10px] text-muted-foreground font-black uppercase tracking-[0.3em]">
          <p>© 2024 Abraham Fantu. High Velocity Impact.</p>
          <div className="flex gap-12">
            <a href="#" className="hover:text-cyan-400 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-cyan-400 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

// --- Main App ---

export default function App() {
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('theme') as 'light' | 'dark';
      return saved || 'dark';
    }
    return 'dark';
  });

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
    toast.info(`Switched to ${theme === 'dark' ? 'Day' : 'Dark'} Mode`, {
      icon: theme === 'dark' ? <Sun size={14} /> : <Moon size={14} />
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground font-sans selection:bg-cyan-400 selection:text-white transition-colors duration-300">
      <Toaster position="top-right" theme={theme} richColors />
      <Navbar theme={theme} toggleTheme={toggleTheme} />
      <main>
        <Hero />
        <Timeline />
        <PodcastHub />
        <AliveAcademy />
        <TazaMarketing />
      </main>
      <Footer />
    </div>
  )
}