# Plan: Update Visionary Section Image

## 1. Update Image Assets
- Replace the `VISIONARY_IMAGE` constant in `src/App.tsx` with the new URL: `https://storage.googleapis.com/dala-prod-public-storage/attachments/6af2f82c-4073-450c-b678-c6d68dff7e08/1777641025526_Layer_3.png`.

## 2. Refine Timeline Section
- Update the `Timeline` component's image container.
- Implement a "background-removed" look using CSS techniques:
    - Use `object-fit: cover` or `contain` as appropriate.
    - Apply a subtle `mask-image` (radial gradient) to fade the edges of the portrait into the dark background.
    - If the background is solid black, use `mix-blend-mode: lighten` or `screen` to blend it seamlessly with the site's dark mode.
- Ensure the image remains on the right side of the "The 28-Year-Old Visionary" header.
- Preserve the existing milestone narrative (the "step-by-step" timeline).

## 3. Visual Polish
- Maintain the Aqua/White brand colors.
- Ensure the transition is smooth using Framer Motion.
- Remove any references to the old visionary portrait.

## 4. Verification
- Validate the build to ensure no breaking changes.
